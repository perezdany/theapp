@extends("layouts.app")

    @section("content")
        @livewire('paiements')
    @endsection