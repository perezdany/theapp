@extends("layouts.app")

    @section("content")
        @livewire('interlocuteurs')
    @endsection