@extends("layouts.app")

    @section("content")
        @livewire('factures')
    @endsection