@extends("layouts.app")

    @section("content")
        @livewire('fonctions')
    @endsection