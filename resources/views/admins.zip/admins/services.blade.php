@extends("layouts.app")

    @section("content")
        @livewire('services')
    @endsection