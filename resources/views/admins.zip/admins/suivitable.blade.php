@extends("layouts.app")

    @section("content")
        @livewire('tablesuivis')
    @endsection