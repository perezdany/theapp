@extends("layouts.app")

    @section("content")
        @livewire('fournisseurs')
    @endsection