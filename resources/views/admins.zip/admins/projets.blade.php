@extends("layouts.app")

    @section("content")
        @livewire('projets')
    @endsection