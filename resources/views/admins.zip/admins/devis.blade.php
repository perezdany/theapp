@extends("layouts.app")

    @section("content")
        @livewire('cotations')
    @endsection