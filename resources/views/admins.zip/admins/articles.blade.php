@extends("layouts.app")

    @section("content")
        @livewire('articles')
    @endsection