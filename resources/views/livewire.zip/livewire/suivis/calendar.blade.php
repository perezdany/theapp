<div class="content-header">
    <div class="container-fluid">
        <a href="suivi_table"><button class="btn btn-info" >
            <b><i class="fa fa-table"></i> ALLER AU TABLEAU</b></button></a>
    </div><!-- /.container-fluid data-toggle="modal" data-target="#addModal"-->
</div>


<div class="card">
   
    
    <div class="card-body">
        <div id='calendar-container' wire:ignore>
            <div id='calendar'></div>
        </div>
    </div>
</div>